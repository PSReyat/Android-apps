package com.shambhala.weightlosscalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/*

1) Create a recycler view.
2) Each entry in the scroller view leads to another view that contains a notepad.
3) The persons details are on that view with the notepad.
4) The person can enter whatever they want in that notepad.

 */
public class Notepad extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notepad);
    }
}